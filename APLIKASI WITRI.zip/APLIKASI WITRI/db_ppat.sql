-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 13 Jun 2017 pada 00.05
-- Versi Server: 5.6.35-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u0919610_ppat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kota`
--

CREATE TABLE `kota` (
  `idkota` int(11) NOT NULL,
  `nama_kota` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kota`
--

INSERT INTO `kota` (`idkota`, `nama_kota`) VALUES
(1, 'Kab. Simeulue'),
(2, 'Kab. Aceh Singkil'),
(3, 'Kab. Aceh Selatan'),
(4, 'Kab. Aceh Tenggara'),
(5, 'Kab. Aceh Timur'),
(6, 'Kab. Aceh Tengah'),
(7, 'Kab. Aceh Barat'),
(8, 'Kab. Aceh Besar'),
(9, 'Kab. Pidie'),
(10, 'Kab. Bireuen'),
(11, 'Kab. Aceh Utara'),
(12, 'Kab. Aceh Barat Daya'),
(13, 'Kab. Gayo Lues'),
(14, 'Kab. Aceh Tamiang'),
(15, 'Kab. Nagan Raya'),
(16, 'Kab. Aceh Jaya'),
(17, 'Kab. Bener Meriah'),
(18, 'Kab. Pidie Jaya'),
(19, 'Kota Banda Aceh'),
(20, 'Kota Sabang'),
(21, 'Kota Langsa'),
(22, 'Kota Lhokseumawe'),
(23, 'Kota Subulussalam'),
(24, 'Kab. Nias'),
(25, 'Kab. Mandailing Natal'),
(26, 'Kab. Tapanuli Selatan'),
(27, 'Kab. Tapanuli Tengah'),
(28, 'Kab. Tapanuli Utara'),
(29, 'Kab. Toba Samosir'),
(30, 'Kab. Labuhan Batu'),
(31, 'Kab. Asahan'),
(32, 'Kab. Simalungun'),
(33, 'Kab. Dairi'),
(34, 'Kab. Karo'),
(35, 'Kab. Deli Serdang'),
(36, 'Kab. Langkat'),
(37, 'Kab. Nias Selatan'),
(38, 'Kab. Humbang Hasundutan'),
(39, 'Kab. Pakpak Bharat'),
(40, 'Kab. Samosir'),
(41, 'Kab. Serdang Bedagai'),
(42, 'Kab. Batu Bara'),
(43, 'Kab. Padang Lawas Utara'),
(44, 'Kab. Padang Lawas'),
(45, 'Kab. Labuhan Batu Selatan'),
(46, 'Kab. Labuhan Batu Utara'),
(47, 'Kab. Nias Utara'),
(48, 'Kab. Nias Barat'),
(49, 'Kota Sibolga'),
(50, 'Kota Tanjung Balai'),
(51, 'Kota Pematang Siantar'),
(52, 'Kota Tebing Tinggi'),
(53, 'Kota Medan'),
(54, 'Kota Binjai'),
(55, 'Kota Padangsidimpuan'),
(56, 'Kota Gunungsitoli'),
(57, 'Kab. Kepulauan Mentawai'),
(58, 'Kab. Pesisir Selatan'),
(59, 'Kab. Solok'),
(60, 'Kab. Sijunjung'),
(61, 'Kab. Tanah Datar'),
(62, 'Kab. Padang Pariaman'),
(63, 'Kab. Agam'),
(64, 'Kab. Lima Puluh Kota'),
(65, 'Kab. Pasaman'),
(66, 'Kab. Solok Selatan'),
(67, 'Kab. Dharmasraya'),
(68, 'Kab. Pasaman Barat'),
(69, 'Kota Padang'),
(70, 'Kota Solok'),
(71, 'Kota Sawah Lunto'),
(72, 'Kota Padang Panjang'),
(73, 'Kota Bukittinggi'),
(74, 'Kota Payakumbuh'),
(75, 'Kota Pariaman'),
(76, 'Kab. Kuantan Singingi'),
(77, 'Kab. Indragiri Hulu'),
(78, 'Kab. Indragiri Hilir'),
(79, 'Kab. Pelalawan'),
(80, 'Kab. S I A K'),
(81, 'Kab. Kampar'),
(82, 'Kab. Rokan Hulu'),
(83, 'Kab. Bengkalis'),
(84, 'Kab. Rokan Hilir'),
(85, 'Kab. Kepulauan Meranti'),
(86, 'Kota Pekanbaru'),
(87, 'Kota D U M A I'),
(88, 'Kab. Kerinci'),
(89, 'Kab. Merangin'),
(90, 'Kab. Sarolangun'),
(91, 'Kab. Batang Hari'),
(92, 'Kab. Muaro Jambi'),
(93, 'Kab. Tanjung Jabung Timur'),
(94, 'Kab. Tanjung Jabung Barat'),
(95, 'Kab. Tebo'),
(96, 'Kab. Bungo'),
(97, 'Kota Jambi'),
(98, 'Kota Sungai Penuh'),
(99, 'Kab. Ogan Komering Ulu'),
(100, 'Kab. Ogan Komering Ilir'),
(101, 'Kab. Muara Enim'),
(102, 'Kab. Lahat'),
(103, 'Kab. Musi Rawas'),
(104, 'Kab. Musi Banyuasin'),
(105, 'Kab. Banyu Asin'),
(106, 'Kab. Ogan Komering Ulu Selatan'),
(107, 'Kab. Ogan Komering Ulu Timur'),
(108, 'Kab. Ogan Ilir'),
(109, 'Kab. Empat Lawang'),
(110, 'Kota Palembang'),
(111, 'Kota Prabumulih'),
(112, 'Kota Pagar Alam'),
(113, 'Kota Lubuklinggau'),
(114, 'Kab. Bengkulu Selatan'),
(115, 'Kab. Rejang Lebong'),
(116, 'Kab. Bengkulu Utara'),
(117, 'Kab. Kaur'),
(118, 'Kab. Seluma'),
(119, 'Kab. Mukomuko'),
(120, 'Kab. Lebong'),
(121, 'Kab. Kepahiang'),
(122, 'Kab. Bengkulu Tengah'),
(123, 'Kota Bengkulu'),
(124, 'Kab. Lampung Barat'),
(125, 'Kab. Tanggamus'),
(126, 'Kab. Lampung Selatan'),
(127, 'Kab. Lampung Timur'),
(128, 'Kab. Lampung Tengah'),
(129, 'Kab. Lampung Utara'),
(130, 'Kab. Way Kanan'),
(131, 'Kab. Tulangbawang'),
(132, 'Kab. Pesawaran'),
(133, 'Kab. Pringsewu'),
(134, 'Kab. Mesuji'),
(135, 'Kab. Tulang Bawang Barat'),
(136, 'Kab. Pesisir Barat'),
(137, 'Kota Bandar Lampung'),
(138, 'Kota Metro'),
(139, 'Kab. Bangka'),
(140, 'Kab. Belitung'),
(141, 'Kab. Bangka Barat'),
(142, 'Kab. Bangka Tengah'),
(143, 'Kab. Bangka Selatan'),
(144, 'Kab. Belitung Timur'),
(145, 'Kota Pangkal Pinang'),
(146, 'Kab. Karimun'),
(147, 'Kab. Bintan'),
(148, 'Kab. Natuna'),
(149, 'Kab. Lingga'),
(150, 'Kab. Kepulauan Anambas'),
(151, 'Kota B A T A M'),
(152, 'Kota Tanjung Pinang'),
(153, 'Kab. Kepulauan Seribu'),
(154, 'Kota Jakarta Selatan'),
(155, 'Kota Jakarta Timur'),
(156, 'Kota Jakarta Pusat'),
(157, 'Kota Jakarta Barat'),
(158, 'Kota Jakarta Utara'),
(159, 'Kab. Bogor'),
(160, 'Kab. Sukabumi'),
(161, 'Kab. Cianjur'),
(162, 'Kab. Bandung'),
(163, 'Kab. Garut'),
(164, 'Kab. Tasikmalaya'),
(165, 'Kab. Ciamis'),
(166, 'Kab. Kuningan'),
(167, 'Kab. Cirebon'),
(168, 'Kab. Majalengka'),
(169, 'Kab. Sumedang'),
(170, 'Kab. Indramayu'),
(171, 'Kab. Subang'),
(172, 'Kab. Purwakarta'),
(173, 'Kab. Karawang'),
(174, 'Kab. Bekasi'),
(175, 'Kab. Bandung Barat'),
(176, 'Kab. Pangandaran'),
(177, 'Kota Bogor'),
(178, 'Kota Sukabumi'),
(179, 'Kota Bandung'),
(180, 'Kota Cirebon'),
(181, 'Kota Bekasi'),
(182, 'Kota Depok'),
(183, 'Kota Cimahi'),
(184, 'Kota Tasikmalaya'),
(185, 'Kota Banjar'),
(186, 'Kab. Cilacap'),
(187, 'Kab. Banyumas'),
(188, 'Kab. Purbalingga'),
(189, 'Kab. Banjarnegara'),
(190, 'Kab. Kebumen'),
(191, 'Kab. Purworejo'),
(192, 'Kab. Wonosobo'),
(193, 'Kab. Magelang'),
(194, 'Kab. Boyolali'),
(195, 'Kab. Klaten'),
(196, 'Kab. Sukoharjo'),
(197, 'Kab. Wonogiri'),
(198, 'Kab. Karanganyar'),
(199, 'Kab. Sragen'),
(200, 'Kab. Grobogan'),
(201, 'Kab. Blora'),
(202, 'Kab. Rembang'),
(203, 'Kab. Pati'),
(204, 'Kab. Kudus'),
(205, 'Kab. Jepara'),
(206, 'Kab. Demak'),
(207, 'Kab. Semarang'),
(208, 'Kab. Temanggung'),
(209, 'Kab. Kendal'),
(210, 'Kab. Batang'),
(211, 'Kab. Pekalongan'),
(212, 'Kab. Pemalang'),
(213, 'Kab. Tegal'),
(214, 'Kab. Brebes'),
(215, 'Kota Magelang'),
(216, 'Kota Surakarta'),
(217, 'Kota Salatiga'),
(218, 'Kota Semarang'),
(219, 'Kota Pekalongan'),
(220, 'Kota Tegal'),
(221, 'Kab. Kulon Progo'),
(222, 'Kab. Bantul'),
(223, 'Kab. Gunung Kidul'),
(224, 'Kab. Sleman'),
(225, 'Kota Yogyakarta'),
(226, 'Kab. Pacitan'),
(227, 'Kab. Ponorogo'),
(228, 'Kab. Trenggalek'),
(229, 'Kab. Tulungagung'),
(230, 'Kab. Blitar'),
(231, 'Kab. Kediri'),
(232, 'Kab. Malang'),
(233, 'Kab. Lumajang'),
(234, 'Kab. Jember'),
(235, 'Kab. Banyuwangi'),
(236, 'Kab. Bondowoso'),
(237, 'Kab. Situbondo'),
(238, 'Kab. Probolinggo'),
(239, 'Kab. Pasuruan'),
(240, 'Kab. Sidoarjo'),
(241, 'Kab. Mojokerto'),
(242, 'Kab. Jombang'),
(243, 'Kab. Nganjuk'),
(244, 'Kab. Madiun'),
(245, 'Kab. Magetan'),
(246, 'Kab. Ngawi'),
(247, 'Kab. Bojonegoro'),
(248, 'Kab. Tuban'),
(249, 'Kab. Lamongan'),
(250, 'Kab. Gresik'),
(251, 'Kab. Bangkalan'),
(252, 'Kab. Sampang'),
(253, 'Kab. Pamekasan'),
(254, 'Kab. Sumenep'),
(255, 'Kota Kediri'),
(256, 'Kota Blitar'),
(257, 'Kota Malang'),
(258, 'Kota Probolinggo'),
(259, 'Kota Pasuruan'),
(260, 'Kota Mojokerto'),
(261, 'Kota Madiun'),
(262, 'Kota Surabaya'),
(263, 'Kota Batu'),
(264, 'Kab. Pandeglang'),
(265, 'Kab. Lebak'),
(266, 'Kab. Tangerang'),
(267, 'Kab. Serang'),
(268, 'Kota Tangerang'),
(269, 'Kota Cilegon'),
(270, 'Kota Serang'),
(271, 'Kota Tangerang Selatan'),
(272, 'Kab. Jembrana'),
(273, 'Kab. Tabanan'),
(274, 'Kab. Badung'),
(275, 'Kab. Gianyar'),
(276, 'Kab. Klungkung'),
(277, 'Kab. Bangli'),
(278, 'Kab. Karang Asem'),
(279, 'Kab. Buleleng'),
(280, 'Kota Denpasar'),
(281, 'Kab. Lombok Barat'),
(282, 'Kab. Lombok Tengah'),
(283, 'Kab. Lombok Timur'),
(284, 'Kab. Sumbawa'),
(285, 'Kab. Dompu'),
(286, 'Kab. Bima'),
(287, 'Kab. Sumbawa Barat'),
(288, 'Kab. Lombok Utara'),
(289, 'Kota Mataram'),
(290, 'Kota Bima'),
(291, 'Kab. Sumba Barat'),
(292, 'Kab. Sumba Timur'),
(293, 'Kab. Kupang'),
(294, 'Kab. Timor Tengah Selatan'),
(295, 'Kab. Timor Tengah Utara'),
(296, 'Kab. Belu'),
(297, 'Kab. Belu                                         '),
(298, 'Kab. Alor'),
(299, 'Kab. Lembata'),
(300, 'Kab. Flores Timur'),
(301, 'Kab. Sikka'),
(302, 'Kab. Ende'),
(303, 'Kab. Ngada'),
(304, 'Kab. Manggarai'),
(305, 'Kab. Rote Ndao'),
(306, 'Kab. Manggarai Barat'),
(307, 'Kab. Sumba Tengah'),
(308, 'Kab. Sumba Barat Daya'),
(309, 'Kab. Nagekeo'),
(310, 'Kab. Manggarai Timur'),
(311, 'Kab. Sabu Raijua'),
(312, 'Kota Kupang'),
(313, 'Kab. Sambas'),
(314, 'Kab. Bengkayang'),
(315, 'Kab. Landak'),
(316, 'Kab. Pontianak'),
(317, 'Kab. Sanggau'),
(318, 'Kab. Ketapang'),
(319, 'Kab. Sintang'),
(320, 'Kab. Kapuas Hulu'),
(321, 'Kab. Sekadau'),
(322, 'Kab. Melawi'),
(323, 'Kab. Kayong Utara'),
(324, 'Kab. Kubu Raya'),
(325, 'Kota Pontianak'),
(326, 'Kota Singkawang'),
(327, 'Kab. Kotawaringin Barat'),
(328, 'Kab. Kotawaringin Timur'),
(329, 'Kab. Kapuas'),
(330, 'Kab. Barito Selatan'),
(331, 'Kab. Barito Utara'),
(332, 'Kab. Sukamara'),
(333, 'Kab. Lamandau'),
(334, 'Kab. Seruyan'),
(335, 'Kab. Katingan'),
(336, 'Kab. Pulang Pisau'),
(337, 'Kab. Gunung Mas'),
(338, 'Kab. Barito Timur'),
(339, 'Kab. Murung Raya'),
(340, 'Kota Palangka Raya'),
(341, 'Kab. Tanah Laut'),
(342, 'Kab. Kota Baru'),
(343, 'Kab. Banjar'),
(344, 'Kab. Barito Kuala'),
(345, 'Kab. Tapin'),
(346, 'Kab. Hulu Sungai Selatan'),
(347, 'Kab. Hulu Sungai Tengah'),
(348, 'Kab. Hulu Sungai Utara'),
(349, 'Kab. Tabalong'),
(350, 'Kab. Tanah Bumbu'),
(351, 'Kab. Balangan'),
(352, 'Kota Banjarmasin'),
(353, 'Kota Banjar Baru'),
(354, 'Kab. Paser'),
(355, 'Kab. Kutai Barat'),
(356, 'Kab. Kutai Kartanegara'),
(357, 'Kab. Kutai Timur'),
(358, 'Kab. Berau'),
(359, 'Kab. Penajam Paser Utara'),
(360, 'Kota Balikpapan'),
(361, 'Kota Samarinda'),
(362, 'Kota Bontang'),
(363, 'Kab. Malinau'),
(364, 'Kab. Bulungan'),
(365, 'Kab. Tana Tidung'),
(366, 'Kab. Nunukan'),
(367, 'Kota Tarakan'),
(368, 'Kab. Bolaang Mongondow'),
(369, 'Kab. Minahasa'),
(370, 'Kab. Kepulauan Sangihe'),
(371, 'Kab. Kepulauan Talaud'),
(372, 'Kab. Minahasa Selatan'),
(373, 'Kab. Minahasa Utara'),
(374, 'Kab. Bolaang Mongondow Utara'),
(375, 'Kab. Siau Tagulandang Biaro'),
(376, 'Kab. Minahasa Tenggara'),
(377, 'Kab. Bolaang Mongondow Selatan'),
(378, 'Kab. Bolaang Mongondow Timur'),
(379, 'Kota Manado'),
(380, 'Kota Bitung'),
(381, 'Kota Tomohon'),
(382, 'Kota Kotamobagu'),
(383, 'Kab. Banggai Kepulauan'),
(384, 'Kab. Banggai'),
(385, 'Kab. Morowali'),
(386, 'Kab. Poso'),
(387, 'Kab. Donggala'),
(388, 'Kab. Toli-toli'),
(389, 'Kab. Buol'),
(390, 'Kab. Parigi Moutong'),
(391, 'Kab. Tojo Una-una'),
(392, 'Kab. Sigi'),
(393, 'Kota Palu'),
(394, 'Kab. Kepulauan Selayar'),
(395, 'Kab. Bulukumba'),
(396, 'Kab. Bantaeng'),
(397, 'Kab. Jeneponto'),
(398, 'Kab. Takalar'),
(399, 'Kab. Gowa'),
(400, 'Kab. Sinjai'),
(401, 'Kab. Maros'),
(402, 'Kab. Pangkajene Dan Kepulauan'),
(403, 'Kab. Barru'),
(404, 'Kab. Bone'),
(405, 'Kab. Soppeng'),
(406, 'Kab. Wajo'),
(407, 'Kab. Sidenreng Rappang'),
(408, 'Kab. Pinrang'),
(409, 'Kab. Enrekang'),
(410, 'Kab. Luwu'),
(411, 'Kab. Tana Toraja'),
(412, 'Kab. Luwu Utara'),
(413, 'Kab. Luwu Timur'),
(414, 'Kab. Toraja Utara'),
(415, 'Kota Makassar'),
(416, 'Kota Parepare'),
(417, 'Kota Palopo'),
(418, 'Kab. Buton'),
(419, 'Kab. Muna'),
(420, 'Kab. Konawe'),
(421, 'Kab. Kolaka'),
(422, 'Kab. Konawe Selatan'),
(423, 'Kab. Bombana'),
(424, 'Kab. Wakatobi'),
(425, 'Kab. Kolaka Utara'),
(426, 'Kab. Buton Utara'),
(427, 'Kab. Konawe Utara'),
(428, 'Kota Kendari'),
(429, 'Kota Baubau'),
(430, 'Kab. Boalemo'),
(431, 'Kab. Gorontalo'),
(432, 'Kab. Pohuwato'),
(433, 'Kab. Bone Bolango'),
(434, 'Kab. Gorontalo Utara'),
(435, 'Kota Gorontalo'),
(436, 'Kab. Majene'),
(437, 'Kab. Polewali Mandar'),
(438, 'Kab. Mamasa'),
(439, 'Kab. Mamuju'),
(440, 'Kab. Mamuju Utara'),
(441, 'Kab. Maluku Tenggara Barat'),
(442, 'Kab. Maluku Tenggara'),
(443, 'Kab. Maluku Tengah'),
(444, 'Kab. Buru'),
(445, 'Kab. Kepulauan Aru'),
(446, 'Kab. Seram Bagian Barat'),
(447, 'Kab. Seram Bagian Timur'),
(448, 'Kab. Maluku Barat Daya'),
(449, 'Kab. Buru Selatan'),
(450, 'Kota Ambon'),
(451, 'Kota Tual'),
(452, 'Kab. Halmahera Barat'),
(453, 'Kab. Halmahera Tengah'),
(454, 'Kab. Kepulauan Sula'),
(455, 'Kab. Halmahera Selatan'),
(456, 'Kab. Halmahera Utara'),
(457, 'Kab. Halmahera Timur'),
(458, 'Kab. Pulau Morotai'),
(459, 'Kota Ternate'),
(460, 'Kota Tidore Kepulauan'),
(461, 'Kab. Fakfak'),
(462, 'Kab. Kaimana'),
(463, 'Kab. Teluk Wondama'),
(464, 'Kab. Teluk Bintuni'),
(465, 'Kab. Manokwari'),
(466, 'Kab. Sorong Selatan'),
(467, 'Kab. Sorong'),
(468, 'Kab. Raja Ampat'),
(469, 'Kab. Tambrauw'),
(470, 'Kab. Maybrat'),
(471, 'Kota Sorong'),
(472, 'Kab. Merauke'),
(473, 'Kab. Jayawijaya'),
(474, 'Kab. Jayapura'),
(475, 'Kab. Nabire'),
(476, 'Kab. Kepulauan Yapen'),
(477, 'Kab. Biak Numfor'),
(478, 'Kab. Paniai'),
(479, 'Kab. Puncak Jaya'),
(480, 'Kab. Mimika'),
(481, 'Kab. Boven Digoel'),
(482, 'Kab. Mappi'),
(483, 'Kab. Asmat'),
(484, 'Kab. Yahukimo'),
(485, 'Kab. Pegunungan Bintang'),
(486, 'Kab. Tolikara'),
(487, 'Kab. Sarmi'),
(488, 'Kab. Keerom'),
(489, 'Kab. Waropen'),
(490, 'Kab. Supiori'),
(491, 'Kab. Mamberamo Raya'),
(492, 'Kab. Nduga'),
(493, 'Kab. Lanny Jaya'),
(494, 'Kab. Mamberamo Tengah'),
(495, 'Kab. Yalimo'),
(496, 'Kab. Puncak'),
(497, 'Kab. Dogiyai'),
(498, 'Kab. Intan Jaya'),
(499, 'Kab. Deiyai'),
(500, 'Kota Jayapura');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `idpengguna` int(11) NOT NULL,
  `NPWP` char(50) NOT NULL,
  `namalengkap` varchar(100) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `notelp` char(15) NOT NULL,
  `alamat` text NOT NULL,
  `level` char(10) NOT NULL,
  `idkota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`idpengguna`, `NPWP`, `namalengkap`, `username`, `password`, `notelp`, `alamat`, `level`, `idkota`) VALUES
(1, '123-72012-123', 'Witri Lizayati', 'developer', '5e8edd851d2fdfbd7415232c67367cc3', '081279786416', 'jogjakarta', 'developer', 167),
(10, '145-2017-234-888-1', 'Witri Lizayati', 'witri', 'e8817ba98de1b50b611ee99762dcfe29', '087738121245', 'sleman', 'admin', 224),
(11, '156-234-890-123', 'salindri sayanaya', 'ppatsleman', '3c52ce7b743cc988d64836f20806952f', '0812543902', 'sleman', 'ppat', 224),
(12, '123-7017-234-222', 'bpnsleman', 'bpnsleman', '2a67f8b9e92d3ae25515b74b645cfedb', '09876543212', 'sleman', 'bpn', 224),
(13, '123-7017-234-223', 'amanah fisabillah bastiar', 'ppatsleman2', '60142a921221a9cafd7f0de9d356fecc', '0987654321', 'jln condong catur yogyakarta', 'ppat', 224),
(14, '123-7017-234-224', 'musdalifah', 'musdalifah', 'b627ee75f03be0235d6ecb2a594dc630', '09876543212', '-', 'ppat', 224),
(15, '123.128.18329.00', 'Nurhayati, A.Md tes', 'aiti', '0cc175b9c0f1b6a831c399e269772661', '08137667832161', 'WWWkabupaten cirebon', 'admin', 167),
(16, '09.415.410.1-426.000', 'Solichin,SH,M.Kn', 'solichin', '0cc175b9c0f1b6a831c399e269772661', '081232486256', 'Jalan Raya Tengah Tani No.40 Kabupaten Cirebon', 'ppat', 167),
(17, '05.155.537.0.212.000', 'Surtiah,A.Md', 'tiah', '0cc175b9c0f1b6a831c399e269772661', '08123372639', 'Kabupaten Cirebon', 'bpn', 167),
(18, '07.087.086.0-426.000', 'HENI SURYANI, SH', 'heni', 'd7afde3e7059cd0a0fe09eec4b0008cd', '0231322813', 'Jalan Flamboyan I No.163 (belakang Polres 852)', 'ppat', 167),
(19, '7.087.499.5-426', 'SITI ARTATI NOVERIYAH,SH', 'siti', '0cc175b9c0f1b6a831c399e269772661', '098765432145', 'Perumahan Taman Pulomas Blok A2 nomor 1, Kedawung,Kab.Cirebon', 'ppat', 167),
(20, '24.788.776.3-426.000', 'Drs. HERMAWAN, MM', 'wawan', '0cc175b9c0f1b6a831c399e269772661', '098765432145', 'Kecamatan Plumbon', 'ppat', 167),
(22, '09.408.278.1-426.000', 'H.EDI KURNIADI, S.Sos.,M.Si', 'edi', '0cc175b9c0f1b6a831c399e269772661', '08135465023', 'Jalan Sunan Malik Ibrahim No.02', 'ppat', 167),
(23, '16.311.337.0.253.000', 'JAHIDIN,S.SiT', 'jahidin', '0cc175b9c0f1b6a831c399e269772661', '09876543212', 'Kabupaten Cirebon', 'bpn', 167),
(24, '07.256.523.0.345.000', 'Rahmat,A.Ptnh.,MM', 'rahmat', '0cc175b9c0f1b6a831c399e269772661', '098765432121', 'Kabupaten Cirebon', 'bpn', 167);

-- --------------------------------------------------------

--
-- Struktur dari tabel `ppat`
--

CREATE TABLE `ppat` (
  `idppat` int(11) NOT NULL,
  `tanggalinput` date NOT NULL,
  `namapemohon` varchar(100) NOT NULL,
  `alamatpemohon` text NOT NULL,
  `namapenerima` varchar(200) NOT NULL,
  `alamatpenerima` varchar(200) NOT NULL,
  `alamattanah` text NOT NULL,
  `jenisakta` varchar(20) NOT NULL,
  `noakta` varchar(100) NOT NULL,
  `tanggalakta` date NOT NULL,
  `jenisaset` char(15) NOT NULL,
  `luastanah` double NOT NULL,
  `luasbangunan` double NOT NULL,
  `harga` double NOT NULL,
  `NOP` varchar(100) NOT NULL,
  `NJOP` varchar(100) NOT NULL,
  `tahun` char(4) NOT NULL,
  `tgl_ssp` date NOT NULL,
  `jumlah_ssp` double NOT NULL,
  `tgl_bphtb` date NOT NULL,
  `jumlah_bphtb` double NOT NULL,
  `status` char(50) NOT NULL,
  `verifikasi` char(30) NOT NULL,
  `keterangan` text NOT NULL,
  `file` varchar(100) NOT NULL,
  `idpengguna` int(11) NOT NULL,
  `jenishak` varchar(100) NOT NULL,
  `nohak` varchar(100) NOT NULL,
  `tgl_penyerahan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ppat`
--

INSERT INTO `ppat` (`idppat`, `tanggalinput`, `namapemohon`, `alamatpemohon`, `namapenerima`, `alamatpenerima`, `alamattanah`, `jenisakta`, `noakta`, `tanggalakta`, `jenisaset`, `luastanah`, `luasbangunan`, `harga`, `NOP`, `NJOP`, `tahun`, `tgl_ssp`, `jumlah_ssp`, `tgl_bphtb`, `jumlah_bphtb`, `status`, `verifikasi`, `keterangan`, `file`, `idpengguna`, `jenishak`, `nohak`, `tgl_penyerahan`) VALUES
(18, '2017-06-12', '1). Ny. IRENA MARIA CHAIDIR 2). NY. SRI NURHAYATI QQ. PT BANK COMMONWEALTH', 'Kabupaten Cirebon', 'TN. JEFFRI EFFENDY', 'Kabupaten Cirebon', 'Sutawinangun', 'APHT', '116', '2017-03-01', 'TANAH', 88, 0, 197000000, '0', '0', '2017', '0000-00-00', 0, '0000-00-00', 0, 'MENUNGGU', 'BELUM DIVERIFIKASI', '-', 'IMG_3578.JPG', 16, 'HM', '1430', '2017-03-09'),
(19, '2017-06-12', 'TN. FAISAL NADJIB AFIFF QQ. PT. MITRA SHAPPHIRE SEJAHTERA', 'Kabupaten Cirebon', 'NY. LILIS LUSIANI', 'Kabupaten Cirebon', 'KALIKOA', 'AJB', '122', '2017-03-01', 'TANAH&BANGUNAN', 128, 54, 140000, '0530.0/2016', '0', '2017', '0000-00-00', 3500000, '0000-00-00', 4000000, 'DITERIMA', 'DIVERIFIKASI', '-', 'uji t.pdf', 16, 'HGB', '1252', '2017-03-09'),
(20, '2017-06-12', 'TN. SONNY ROKHMAN SUDRAJAT, NY. LIA KUSMANAYANTI', 'Kabupaten Cirebon', 'TN. MACHFUD HATTA', 'GEGUNUNG', 'GEGUNUNG', 'AJB', '139', '2017-04-10', 'TANAH&BANGUNAN', 340, 120, 100000, '0', '0', '2017', '0000-00-00', 2500000, '0000-00-00', 2000000, 'MENUNGGU', 'BELUM DIVERIFIKASI', '-', 'Info_Gaji 13_2017.pdf', 16, 'HM', '139', '2017-04-18'),
(21, '2017-06-12', 'TN. AHMAD', 'Kabupaten Cirebon', 'TN. ALEX', 'Kabupaten Cirebon', 'Cilegun', 'Inbreng', '140', '2017-04-12', 'TANAH&BANGUNAN', 1500, 750, 500000000, '0', '0', '2017', '0000-00-00', 0, '0000-00-00', 0, 'DITERIMA', 'DIVERIFIKASI', '-', 'UU_NO_5_2014_ASN.pdf', 16, 'HP', '1430', '2017-04-20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `teguran`
--

CREATE TABLE `teguran` (
  `idteguran` int(11) NOT NULL,
  `tgl_konfirmasi` date NOT NULL,
  `bulan` char(30) NOT NULL,
  `idpengguna` int(11) NOT NULL,
  `file_teguran` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `teguran`
--

INSERT INTO `teguran` (`idteguran`, `tgl_konfirmasi`, `bulan`, `idpengguna`, `file_teguran`) VALUES
(5, '2017-06-04', '01', 16, 'perbaikan lagi (3).docx'),
(6, '2017-06-04', '02', 16, 'Perbaikan (1).docx');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`idkota`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`idpengguna`);

--
-- Indexes for table `ppat`
--
ALTER TABLE `ppat`
  ADD PRIMARY KEY (`idppat`);

--
-- Indexes for table `teguran`
--
ALTER TABLE `teguran`
  ADD PRIMARY KEY (`idteguran`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `idpengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `ppat`
--
ALTER TABLE `ppat`
  MODIFY `idppat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `teguran`
--
ALTER TABLE `teguran`
  MODIFY `idteguran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
